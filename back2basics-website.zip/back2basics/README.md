# Back2Basics — Gemeentewebsite

Statische website voor gemeente Back2Basics in Beverwijk.
Gebouwd met gewone HTML, CSS en JavaScript — geen frameworks, geen buildtools.

## 📁 Mappenstructuur

```
back2basics/
│
├── index.html          ← Homepage met dashboard
├── agenda.html         ← Volledige agenda
├── nieuws.html         ← Nieuwsberichten
├── wie-zijn-wij.html   ← Over de gemeente
├── contact.html        ← Contactpagina + formulier
│
├── css/
│   └── style.css       ← Alle stijlen
│
├── js/
│   └── main.js         ← Alle logica (sidebar, data laden, etc.)
│
└── data/
    ├── agenda.json     ← Agenda data ← HIER AANPASSEN
    └── nieuws.json     ← Nieuws data  ← HIER AANPASSEN
```

## ✏️ Nieuws toevoegen

Open `data/nieuws.json` en voeg een nieuw object toe aan het begin van de lijst:

```json
{
  "id": 4,
  "datum": "2026-06-10",
  "titel": "Titel van het bericht",
  "samenvatting": "Korte samenvatting die op de homepage te zien is.",
  "tekst": "De volledige tekst van het nieuwsbericht staat hier.",
  "auteur": "Naam Auteur",
  "afbeelding": ""
}
```

## 📅 Agenda bijwerken

Open `data/agenda.json` en voeg een nieuwe dienst toe:

```json
{
  "id": 6,
  "datum": "2026-07-12",
  "tijd": "10:00",
  "titel": "Zondagsdienst",
  "spreker": "Naam Spreker",
  "thema": "Thema van de dienst",
  "locatie": "Hoofdzaal"
}
```

## 🚀 Live zetten (Vercel)

1. Maak een gratis account op [github.com](https://github.com)
2. Maak een nieuwe repository aan (bv. `back2basics-website`)
3. Upload alle bestanden via `git push`
4. Maak een gratis account op [vercel.com](https://vercel.com)
5. Koppel je GitHub-repository aan Vercel
6. Vercel detecteert automatisch dat het een statische site is
7. Klaar — je site is live!

Bij elke `git push` wordt de site automatisch bijgewerkt.

## 🌐 Domeinnaam koppelen

1. Koop een domeinnaam via bv. [TransIP](https://transip.nl)
2. Ga in Vercel naar Settings → Domains
3. Voer je domeinnaam in
4. Pas de DNS-instellingen aan bij TransIP zoals Vercel aangeeft
5. Binnen een paar uur is je domeinnaam actief

## 📝 Lokaal testen

Omdat de site JSON-bestanden inlaadt via `fetch()`, heb je een lokale server nodig.
De makkelijkste manier:

```bash
# Als je Python hebt:
python3 -m http.server 8000

# Of via VS Code: installeer de extensie "Live Server"
```

Open daarna `http://localhost:8000` in je browser.
